const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs'); // For File System operations

const app = express();
const PORT = 3000;

// Correct path to your users.txt file
const usersFilePath = path.join(__dirname, 'users.txt');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: 'your_secret_key_here',
    resave: false,
    saveUninitialized: true,
  })
);
// Read users data from users.txt file
function readUsersData() {
  if (!fs.existsSync(usersFilePath)) {
    // If the file doesn't exist, return an empty object
    return {};
  }

  const data = fs.readFileSync(usersFilePath, 'utf-8');
  try {
    return JSON.parse(data); // Parse the JSON data
  } catch (err) {
    console.error('Error reading users data:', err);
    return {};
  }
}

// Write users data to users.txt file
function writeUsersData(users) {
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2), 'utf-8'); // Pretty print JSON
}

// Routes
app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/home');
  }
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // Read users data from users.txt
  const users = readUsersData();

  // Check if username exists and the password is correct
  if (users[username] && await bcrypt.compare(password, users[username].password)) {
    req.session.user = username;
    return res.redirect('/home');
  } else {
    res.status(401).send(`<script>alert('Invalid username or password'); window.location.href = '/';</script>`);
  }
});

app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});

app.post('/signup', async (req, res) => {
  const { username, password, confirmPassword } = req.body;

  // Read users data from users.txt
  const users = readUsersData();

  if (users[username]) {
    res.status(400).send(`<script>alert('Username already exists'); window.location.href = '/signup';</script>`);
  } else if (password !== confirmPassword) {
    res.status(400).send(`<script>alert('Passwords do not match'); window.location.href = '/signup';</script>`);
  } else {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save the user with their hashed password
    users[username] = { password: hashedPassword };
    writeUsersData(users); // Save data to users.txt
    res.send(`<script>alert('Account created successfully!'); window.location.href = '/';</script>`);
  }
});

app.get('/home', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'views', 'home.html'));
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
